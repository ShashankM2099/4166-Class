const express = require('express');
const controller = require('../controllers/userController.js');
const router = express.Router();

router.get('/new', controller.new);
router.post('/new',controller.addDetails);
router.get('/login', controller.login);
router.post('/login',controller.verify);
router.get('/profile', controller.profile);
router.get('/logout',controller.logout)

module.exports = router;