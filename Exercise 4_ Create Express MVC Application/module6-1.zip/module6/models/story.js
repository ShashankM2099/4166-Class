const { DateTime } = require("luxon");
const { v4: uuidv4 } = require('uuid');
const stories = [
    {
        id: '1',
        title: 'A funny story',
        content: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod',
        author: 'Morbius',
        createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },

    {
        id: '2',
        title: 'Not so funny story',
        content: 'quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
        author: 'Kraven Sergei',
        createdTime: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    }
];

exports.find = () => {
    return stories;
}

exports.findById = function (id) {
    return stories.find(story => story.id === id);
}

exports.save = () => {
    story.id = uuidv4();
    story.createdAt = DateTime.now().toLocaleString(DateTime.DATETIME_SHORT);
    stories.push(story);
}

exports.updateById = (id, newStory) => {
    let story = stories.find(story => story.id === id);
    if (story) {
        story.title = newStory.title;
        story.content = newStory.content;
        return true;
    }
    else
        return false;

}

exports.deleteById = (id) => {
    let index = stories.findIndex(stories.find(story => story.id === id));
    if (index !== -1) {
        stories.splice(index, 1);
        return true;

    }
    else
        return false;
}

//console.log(stories[0]);