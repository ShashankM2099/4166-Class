const { Router } = require('express');
const express = require('express');
const res = require('express/lib/response');
//---------------------------------------------------------
const router = express.Router();
const controller = require ('../controllers/storyController');

// GET /stories: send all stories to the user
router.get('/', controller.index);

//GET /stories/new to send html for creating a new story
router.get('/new',controller.new);

//GET /stories creating a new story
router.post('/', controller.create);


//GET /stories/:id sending details of story
router.get('/:id', controller.show);

//GET /stories/:id/edit send form to edit an existing story
router.get('/:id/edit', controller.edit);

//PUT /stories/:id update the story = id
router.put('/:id', controller.update) ;

//DELETE /stories/:id delete stories = id
router.delete('/:id', controller.delete);

module.exports = router;