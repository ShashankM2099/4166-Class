const User = require('../models/user');

exports.login = (req, res) => {
    console.log(req.flash());
    res.render('./user/login');
};

exports.new = (req, res) => {
    res.render('./user/new');
};

exports.addDetails = (req,res,next) => {
    let user = new User(req.body);
    user.save()
    .then(() => {
        req.flash('--Success--','Sign up successful. Now You Can Log In.');
        res.redirect('/users/login');})
    .catch(err =>{ 
        if(err.name === 'ValidationError') {
            req.flash('error', err.message);
            return res.redirect('/users/new');
        }
        if(err.code === 11000) {
            req.flash('error', 'Email address has already been used');
            return res.redirect('/users/new');
        }
        next(err);
    });
};

exports.profile = (req, res, next) => {
    let id = req.session.user;
    User.findById(id)
    .then(user => res.render('./user/profile',{user}))
    .catch(err => next(err));  
};

exports.verify = (req,res,next) => {
    let email = req.body.email;
    let password = req.body.password;
    User.findOne({email: email})
    .then(user => {
        if(user) {
            user.comparePassword(password)
            .then(result => {
                if(result) {
                    req.session.user = user._id;
                    req.flash('Success','Login successful')
                    res.redirect('/users/profile');
                } else {
                    //console.log('Wrong password');
                    req.flash('Error','Wrong password')
                    res.redirect('/users/login');
                }
            })
        } else {
            //console.log('Wrong email address');
            req.flash('--Error--','Wrong Email Address');
            res.redirect('/users/login');
        }
    })
    .catch(err => next(err));
};

exports.logout = (req,res,next) => {
    req.session.destroy(err => {
        if(err)
            return next(err);
        else
            res.redirect('/users/login')
    });
};