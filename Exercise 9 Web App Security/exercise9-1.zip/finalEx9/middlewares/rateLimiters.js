const rateLimit = require("express-rate-limit");

exports.logInLimiter = rateLimit({
    WindowMs: 60 * 1000,
    max: 6,
    //message: 'To many log in requests. Try again later'
    handler: (req, res, next) => {
        let err = new Error('Too many login request. Try again later');
        err.status = 429;
        return next(err);
    }
});