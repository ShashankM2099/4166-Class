const model = require('../models/story');



// GET /stories: send all stories to the user
exports.index = ('/', (req, res) => {
    let stories = model.find();
    res.render('./story/index', { stories });
})

//GET /stories/new to send html for creating a new story
exports.new = ((req, res) => {
    res.render('./story/new');
});

//GET /stories creating a new story
exports.create = ((req, res) => {
    let story = req.body;
    model.save(story);
    res.redirect('/stories');
    //res.send('Created a brand new story');
});

//GET /stories/:id sending details of story
exports.show = ((req, res, next) => {
    let id = req.params.id;
    let story = model.findById(id);
    if (story) {
        res.render('./story/show', { story });
    }
    else {
        //res.status(404).send('Cannot find the story with the ID' + id);
        let err = new Error('Cannot find a story with the id'+ id);
        err.status = 404;
        next(err);
    }
    //res.render('./story/show', {story});
});

//GET /stories/:id/edit send form to edit an existing story
exports.edit = ((req, res, next) => {
    let id = req.params.id;
    let story = model.findById(id);
    if (story) {
        res.render('./story/edit', { story });
    }
    else {
        //res.status(404).send('Cannot find the story with the ID' + id);
        let err = new Error('Cannot find a story with the id'+ id);
        err.status = 404;
        next(err);
    }
    //res.send('Send the Edit Form ');
});

//PUT /stories/:id update the story = id
exports.update = ((req, res, next) => {
    let story = req.body;
    //console.story;
    let id = req.params.id;
    if(model.updateById(id,story)){
        res.redirect('/stories/' + id);
    }
    else {
        //res.status(404).send('Cannot find the story with the ID' + id);
        let err = new Error('Cannot find a story with the id'+ id);
        err.status = 404;
        next(err);
    }
    //res.send('Update the story with ID ' + req.params.id);
});

//DELETE /stories/:id delete stories = id
exports.delete = ((req, res, next) => {
    //res.send('Deleted the story with ID ' + req.params.id);
    let id = req.params.id;
    if(model.deleteById(id)){
        res.redirect('/stories/');
    }
    else {
        //res.status(404).send('Cannot find the story with the ID' + id);
        let err = new Error('Cannot find a story with the id'+ id);
        err.status = 404;
        next(err);
    }
});